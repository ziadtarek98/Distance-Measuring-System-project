/*
 * mini_project_test_4.c
 *
 *  Created on: Apr 18, 2023
 *      Author: ZIAD T.HOSNY
 */

#include "Ultrasonic.h"
#include "icu.h"
#include "avr/io.h"
#include "lcd.h"
#include "gpio.h"
#include "common_macros.h"
#include "std_types.h"
#include "util/delay.h"

int main(void){
	uint16 total_distance=0;

	Ultrasonic_init();//this function is called icu init

	LCD_init();

	/**************************************/
	/* Display my name on lcd */
	LCD_moveCursor(0,0);
	LCD_displayString("Ziad T.Hosny");

	LCD_moveCursor(1,3);
	LCD_displayString("project");

	_delay_ms(2000);

	LCD_clearScreen();
	/*****************************************/

	LCD_moveCursor(0,0);

	/* Display this string "Distance =   CM" only once on LCD at the first row */
	LCD_displayString("Distance=    CM");


	while(1){
		/*SEND THE TRIGGER PULSE TO SET SENSOR ON AND SEND SOUND WAVES */
		Ultrasonic_Trigger();

		total_distance=Ultrasonic_readDistance();

		if((total_distance<100) & (total_distance>=2)){

			LCD_moveCursor(1,2);
			LCD_displayString("             ");/*TO DELETE THE STRING (OUT OF RANGE)*/
			LCD_moveCursor(0,10);
			LCD_intgerToString(total_distance);//DISPLAY THE DISTANCE
			LCD_moveCursor(0,12);
			LCD_displayCharacter(' ');//DELETE THE THIRD CHARACTER
		}


		else if((total_distance>=100) & (total_distance<=333)) {

			LCD_moveCursor(1,2);
			LCD_displayString("             ");
			LCD_moveCursor(0,10);
			LCD_intgerToString(total_distance);
		}


		else {
			LCD_moveCursor(0,10);
			LCD_intgerToString(total_distance);
			LCD_moveCursor(1,2);
			LCD_displayString("OUT OF RANGE");

		}

	}

}
















