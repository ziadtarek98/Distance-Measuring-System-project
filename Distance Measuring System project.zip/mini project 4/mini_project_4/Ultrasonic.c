/*
 * Ultrasonic.c
 *
 *  Created on: Apr 16, 2023
 *      Author: Author: ZIAD T.HOSNY
 */
#include "Ultrasonic.h"
#include "icu.h"
#include "gpio.h"
#include "avr/io.h"
#include "common_macros.h"
#include "std_types.h"
#include "util/delay.h"

uint16 g_timeHigh = 0;
uint16 g_timePeriod = 0;

/*************************************************************************************************
 *                              ULTRASONIC FUNCTIONS
 *************************************************************************************************/


void Ultrasonic_init(void){

	Icu_ConfigType Icu_Config = {F_CPU_8,RISING};
	Icu_init(&Icu_Config);

	Icu_setCallBack(&Ultrasonic_edgeProcessing);

	/* SET THE TRIGGER PIN DIRECTION AND PUT IT LOGIC LOW IN THE FIRST*/
	GPIO_setupPinDirection(TRIGGER_PORT_ID,TRIGGER_PIN_ID,PIN_OUTPUT);
	GPIO_writePin(TRIGGER_PORT_ID,TRIGGER_PIN_ID,LOGIC_LOW);

	/* SET THE ECHO PIN DIRECTION AS INPUT PIN */
	//	GPIO_setupPinDirection(ECHO_PORT_ID,ECHO_PIN_ID,PIN_INPUT);
}


/*************************************************************************************************/


void Ultrasonic_Trigger(void){

	TCCR1A = 0;
	TIFR = (1<<ICF1);

	/* WRITE ON TRIGGER PIN WITH LOGIC HIGH TO SEND THE FIRST PULSE*/
	GPIO_writePin(TRIGGER_PORT_ID,TRIGGER_PIN_ID,LOGIC_HIGH);

	_delay_us(50);//this delay to start ultrasonic send the waves

	GPIO_writePin(TRIGGER_PORT_ID,TRIGGER_PIN_ID,LOGIC_LOW);
}


/*************************************************************************************************/

uint16 Ultrasonic_readDistance(void){
	uint16 Distance=0,ECHO_time=0;

	//	Ultrasonic_Trigger();//SEND THE TRIGGER PULSE

	Ultrasonic_edgeProcessing();//calculate the pulse time

	/*
	 * Distance= sound speed * time
	 * total distance = (34000*ECHO time)/2	to find the real distance
	 * total distance (cm)=17000*ECHO time
	 * work on F_CPU/8 (8MHz)
	 * distance=17000 x (TIMER value) x 1 x 10^-6 cm
	 * distance=(TIMER value) / 58.8 cm
	 */

	ECHO_time=g_timePeriod;
	Distance=(ECHO_time)*(0.0155);


	return Distance;
}

/*************************************************************************************************/


void Ultrasonic_edgeProcessing(void)
{

	Icu_clearTimerValue();
	/* set the first pulse is rising edge */
	Icu_setEdgeDetectionType(RISING);

	/* if the pin clear that mean the pulse fall to zero*/
	while ((TIFR&(1<<ICF1)) == 0);
	g_timeHigh = Icu_getInputCaptureValue();
	TIFR = (1<<ICF1); // CLEAR INPUT CAPTURE FLAG

	Icu_setEdgeDetectionType(FALLING);
	while ((TIFR&(1<<ICF1)) == 0);
	g_timePeriod = Icu_getInputCaptureValue();
	TIFR = (1<<ICF1);
	Icu_clearTimerValue();

}





